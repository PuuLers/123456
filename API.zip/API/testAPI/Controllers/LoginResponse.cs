namespace testAPI.Controllers;

public partial class ApiController
{
    public class LoginResponse
    {
        public int Id { get; set; }
        public string? Name { get; set; }
    }
}
