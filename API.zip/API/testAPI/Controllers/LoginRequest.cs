namespace testAPI.Controllers;

public class LoginRequest
    {
        public string? Name { get; set; }
        public string? Password { get; set; }
    }
