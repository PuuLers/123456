﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Net.Http;
using System.Net.Http.Json; // Для GetFromJsonAsync
using System.Runtime.CompilerServices;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WpfContest.Models;

namespace WpfContest
{

    public partial class Vhod : Window
    {
        private readonly HttpClient _httpClient;
        private bool _loginButtonErrorState = false; 

        public bool LoginButtonErrorState
        {
            get => _loginButtonErrorState;
            set
            {
                _loginButtonErrorState = value;
            }
        }

        public Vhod()
        {
            InitializeComponent();

            _httpClient = new HttpClient();
            _httpClient.BaseAddress = new Uri("http://localhost:5013/"); // ЗАМЕНИТЕ НА URL ВАШЕГО API
            _httpClient.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            ClearError(); 
            ((Button)sender).IsEnabled = false;

            string username = UsernameTextBox.Text;
            string password = PasswordBox.Password;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                ShowError("Please enter both username and password.");
                ((Button)sender).IsEnabled = true; // Включаем кнопку обратно
                return;
            }

            var loginData = new LoginRequest { Name = username, Password = password };

            try
            {
                var response = await _httpClient.PostAsJsonAsync("user", loginData);
                AuthResponse authResult = null!;
                if (response.Content != null)
                {
                    try
                    {
                        authResult = await response.Content.ReadFromJsonAsync<AuthResponse>();
                    }
                    catch (JsonException jsonEx)
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            ShowError("Invalid API response format.");
                            ((Button)sender).IsEnabled = true;
                            return;
                        }
                    }
                }

                bool loginSuccess = false;
                if (authResult != null)
                {
                    loginSuccess = authResult.Success;
                }
                else if (response.IsSuccessStatusCode)
                {
                    loginSuccess = true;
                }

                if (loginSuccess)
                {
                    TransitionToMainWindow();
                }
                else
                {
                    string errorMessage = authResult?.Message ?? "Login failed. Please try again.";
                    ShowError(errorMessage);
                    SetButtonErrorState(true);
                    PasswordBox.Password = ""; // Очищаем пароль
                }
            }
            catch (HttpRequestException httpEx)
            {
                ShowError($"Network error: {httpEx.Message}");
                SetButtonErrorState(true); // Красный цвет при сетевой ошибке
            }
            catch (Exception ex)
            {
                ShowError($"An unexpected error occurred: {ex.Message}");
                SetButtonErrorState(true); // Красный цвет при любой другой ошибке
            }
            finally
            {
                if (!loginSuccess) // Только если вход не удался
                {
                    ((Button)sender).IsEnabled = true;
                }
            }
        }

        // Метод для перехода на главное окно
        private void TransitionToMainWindow()
        {
            this.Close(); // Закрываем окно входа
            var mainWindow = new MainWindow();
            mainWindow.Show();
        }

        private void ShowError(string message)
        {
            ErrorMessageTextBlock.Text = message;
            ErrorMessageTextBlock.Visibility = Visibility.Visible;
            SetButtonErrorState(true);
        }

        private void ClearError()
        {
            ErrorMessageTextBlock.Visibility = Visibility.Collapsed;
            ErrorMessageTextBlock.Text = "";
            SetButtonErrorState(false); 
            var button = (Button)this.FindName("LoginButton"); 
            if (button != null) button.IsEnabled = true; // Включаем кнопку
        }

        private void SetButtonErrorState(bool isError)
        {
            _loginButtonErrorState = isError;
            var button = (Button)this.FindName("LoginButton"); 
            if (button != null)
            {
                button.Style = (Style)this.FindResource("LoginButtonStyle");
            }
        }


    }

    public class LoginRequest
    {
        public string? Name { get; set; }
        public string? Password { get; set; }
    }

    public class AuthResponse
    {
        public bool Success { get; set; }
        public string? Message { get; set; }
    }
}
