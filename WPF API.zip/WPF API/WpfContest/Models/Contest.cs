using System.Windows.Controls;

namespace WpfContest.Models;

public class Employee
{
    public string? FullName { get; set; }
    public DateTime? Birthday { get; set; }
    public string? Division { get; set; }
    public string? Post { get; set; }
    public string? WorkingPhone { get; set; }
    public string? MobilePhone { get; set; }
    public string? OfficeNumber { get; set; }
    public string? CorporateEmail { get; set; }
    public string? PersonalEmail { get; set; }
    public string? OtherInformation { get; set; }

    public string DivisionPost => $"{Division} - {Post}";
    public string ContactInfo => $"{WorkingPhone} {CorporateEmail}";
}

public class Division
{
    public int id_division { get; set; }
    public string? DivisionName { get; set; }
    public string? DivisionDescription { get; set; }
    public int id_parent { get; set; }
    public int Level { get; set; }
}

public class Users
{
    public int id { get; set; }
    public string? name { get; set; }
    public string? password { get; set; }
}
