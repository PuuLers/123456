using System.Collections.ObjectModel;
using System.Net.Http;
using System.Net.Http.Json;
using System.Windows;
using WpfContest.Models;

namespace WpfContest;

public partial class MainWindow : Window
{
    private static readonly HttpClient _httpClient = new() { BaseAddress = new Uri("http://localhost:5013/") };

    public ObservableCollection<Employee> Employees { get; set; } = [];
    public ObservableCollection<Division> Level0Divisions { get; set; } = [];
    public ObservableCollection<Division> Level1Divisions { get; set; } = [];
    public ObservableCollection<Division> Level2Divisions { get; set; } = [];

    public MainWindow()
    {
        InitializeComponent();
        DataContext = this;
        EmployeeListBox.ItemsSource = Employees;
        _ = LoadDataAsync();
    }

    private async Task LoadDataAsync()
    {
        try
        {
            var employees = await _httpClient.GetFromJsonAsync<List<Employee>>("api/staff");
            if (employees != null)
                foreach (var emp in employees) Employees.Add(emp);

            var divisions = await _httpClient.GetFromJsonAsync<List<Division>>("api/division");
            if (divisions != null)
                foreach (var div in divisions)
                    (div.Level switch { 0 => Level0Divisions, 1 => Level1Divisions, 2 => Level2Divisions, _ => null })?.Add(div);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }
}
