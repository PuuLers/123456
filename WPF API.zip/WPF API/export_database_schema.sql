-- SQL Script для экспорта схемы таблиц Division, Post, Staff и представления StaffPostDivision
-- Для MS SQL Server

-- ============================================
-- Таблица Division
-- ============================================
SELECT
    'Division' AS TableName,
    COLUMN_NAME AS ColumnName,
    DATA_TYPE AS DataType,
    CHARACTER_MAXIMUM_LENGTH AS MaxLength,
    IS_NULLABLE AS IsNullable,
    COLUMN_DEFAULT AS DefaultValue
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Division'
ORDER BY ORDINAL_POSITION;

-- ============================================
-- Таблица Post
-- ============================================
SELECT
    'Post' AS TableName,
    COLUMN_NAME AS ColumnName,
    DATA_TYPE AS DataType,
    CHARACTER_MAXIMUM_LENGTH AS MaxLength,
    IS_NULLABLE AS IsNullable,
    COLUMN_DEFAULT AS DefaultValue
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Post'
ORDER BY ORDINAL_POSITION;

-- ============================================
-- Таблица Staff
-- ============================================
SELECT
    'Staff' AS TableName,
    COLUMN_NAME AS ColumnName,
    DATA_TYPE AS DataType,
    CHARACTER_MAXIMUM_LENGTH AS MaxLength,
    IS_NULLABLE AS IsNullable,
    COLUMN_DEFAULT AS DefaultValue
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Staff'
ORDER BY ORDINAL_POSITION;

-- ============================================
-- Представление StaffPostDivision
-- ============================================
SELECT
    'StaffPostDivision' AS ViewName,
    COLUMN_NAME AS ColumnName,
    DATA_TYPE AS DataType,
    CHARACTER_MAXIMUM_LENGTH AS MaxLength,
    IS_NULLABLE AS IsNullable
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'StaffPostDivision'
ORDER BY ORDINAL_POSITION;

-- ============================================
-- Альтернативный вариант с более детальной информацией
-- ============================================

-- Дополнительная информация о колонках с использованием sys.columns
/*
SELECT
    t.name AS TableName,
    c.name AS ColumnName,
    ty.name AS DataType,
    c.max_length AS MaxLength,
    c.precision AS Precision,
    c.scale AS Scale,
    c.is_nullable AS IsNullable,
    c.is_identity AS IsIdentity
FROM sys.tables t
INNER JOIN sys.columns c ON t.object_id = c.object_id
INNER JOIN sys.types ty ON c.user_type_id = ty.user_type_id
WHERE t.name IN ('Division', 'Post', 'Staff')
ORDER BY t.name, c.column_id;

-- Информация о представлении
SELECT
    v.name AS ViewName,
    c.name AS ColumnName,
    ty.name AS DataType,
    c.max_length AS MaxLength,
    c.precision AS Precision,
    c.scale AS Scale,
    c.is_nullable AS IsNullable
FROM sys.views v
INNER JOIN sys.columns c ON v.object_id = c.object_id
INNER JOIN sys.types ty ON c.user_type_id = ty.user_type_id
WHERE v.name = 'StaffPostDivision'
ORDER BY c.column_id;
*/
